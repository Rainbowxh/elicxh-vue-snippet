<h1>elicxh vue snippets</h1>

![vscode](https://img.shields.io/badge/vscode->=1.89.0-blue)

This is a VSCode snippet extension designed to assist with the Vue Composition API.

The extension can automatically complete import statements and generate the simplest examples.

Consider supporting more UI frameworks.

## Use it

### vue
You can get completion suggestions by typing 'v' in front of the desired command

![](https://github.com/Rainbowxh/elicxh-vue-snippet/blob/develop/screenshots/image1.png?raw=true)

![](https://github.com/Rainbowxh/elicxh-vue-snippet/blob/develop/screenshots/image2.png?raw=true)


#### Thanks
---
logo design: @kv




